using UnityEngine;

namespace Babel
{
    public class MainMenuUIManager : MonoBehaviour
    {
        [Header("UI Refs")]
        public RectTransform titleText;
        public RectTransform root;

        [Header("Camera Refs")]
        public Transform cameraTargetPivot;

        [Header("UI Move Settings")]
        public float titleMoveSpeed = 2.0f;
        public float rootMoveSpeed = 2.0f;
        public float titleStartDelay = 0.1f;
        public float rootStartDelay = 0.25f;

        [Header("Camera Move Settings")]
        public Vector3 cameraStartOffset = new Vector3(0, 8, 0);
        public Vector3 cameraTargetOffset = Vector3.zero;
        public float cameraMoveSpeed = 1.2f;

        [Header("Camera Floating Settings")]
        public float floatingAmount = 0.25f;
        public float floatingSpeed = 0.6f;
        public float floatingFollowSpeed = 1.2f;

        private Camera cam;
        private RectTransform canvasRectTransform;

        private Vector2 titleRootPosition;
        private Vector2 rootRootPosition;

        private float introTimer;
        private float floatingTimer;
        private float cameraZ;

        private bool cameraIntroFinished = false;

        private void Awake()
        {
            cam = Camera.main;
            canvasRectTransform = GetComponent<RectTransform>();

            cameraZ = cam.transform.position.z;

            // 인스펙터 연결을 깜빡했을 때를 위한 보조 처리
            if (titleText == null)
            {
                Transform titleTransform = transform.Find("TitleText");
                if (titleTransform != null)
                {
                    titleText = titleTransform.GetComponent<RectTransform>();
                }
            }

            if (root == null)
            {
                Transform rootTransform = transform.Find("Root");
                if (rootTransform != null)
                {
                    root = rootTransform.GetComponent<RectTransform>();
                }
            }
        }

        private void Start()
        {
            SetStartPositions();
        }

        private void Update()
        {
            introTimer += Time.deltaTime;

            MoveTitleText();
            MoveRoot();
            CameraWork();
        }

        private void SetStartPositions()
        {
            float screenHeight = canvasRectTransform.rect.height;
            float screenWidth = canvasRectTransform.rect.width;

            if (titleText != null)
            {
                titleRootPosition = titleText.anchoredPosition;

                // TitleText는 위에서 내려오게
                titleText.anchoredPosition =
                    titleRootPosition + new Vector2(0, screenHeight + titleText.rect.height);
            }

            if (root != null)
            {
                rootRootPosition = root.anchoredPosition;

                // Root는 오른쪽에서 들어오게
                root.anchoredPosition =
                    rootRootPosition + new Vector2(screenWidth + root.rect.width, 0);
            }

            if (cam != null)
            {
                Vector3 targetPos = GetCameraBasePosition();

                // 카메라는 최종 위치보다 위에서 시작
                cam.transform.position = targetPos + cameraStartOffset;
            }
        }

        private void MoveTitleText()
        {
            if (titleText == null) return;
            if (introTimer < titleStartDelay) return;

            if (Vector2.Distance(titleText.anchoredPosition, titleRootPosition) >= 0.1f)
            {
                titleText.anchoredPosition = Vector2.Lerp(
                    titleText.anchoredPosition,
                    titleRootPosition,
                    Time.deltaTime * titleMoveSpeed
                );
            }
        }

        private void MoveRoot()
        {
            if (root == null) return;
            if (introTimer < rootStartDelay) return;

            if (Vector2.Distance(root.anchoredPosition, rootRootPosition) >= 0.1f)
            {
                root.anchoredPosition = Vector2.Lerp(
                    root.anchoredPosition,
                    rootRootPosition,
                    Time.deltaTime * rootMoveSpeed
                );
            }
        }

        private void CameraWork()
        {
            if (cam == null) return;

            Vector3 baseTargetPos = GetCameraBasePosition();
            Vector3 targetPos = baseTargetPos;

            if (cameraIntroFinished == false)
            {
                if (Vector2.Distance(cam.transform.position, baseTargetPos) <= 0.1f)
                {
                    cameraIntroFinished = true;
                }
            }
            else
            {
                // 내려온 뒤에는 수면 위에 떠있는 느낌으로 천천히 위아래 이동
                floatingTimer += Time.deltaTime;
                float floatingY = Mathf.Sin(floatingTimer * floatingSpeed) * floatingAmount;

                targetPos.y += floatingY;
            }

            float speed = cameraIntroFinished ? floatingFollowSpeed : cameraMoveSpeed;

            Vector3 lerpPos = Vector3.Lerp(
                cam.transform.position,
                targetPos,
                Time.deltaTime * speed
            );

            lerpPos.z = cameraZ;
            cam.transform.position = lerpPos;
        }

        private Vector3 GetCameraBasePosition()
        {
            Vector3 targetPos;

            if (cameraTargetPivot != null)
            {
                targetPos = cameraTargetPivot.position + cameraTargetOffset;
            }
            else
            {
                targetPos = cam.transform.position;
            }

            targetPos.z = cameraZ;
            return targetPos;
        }
    }
}